<link rel="shortcut icon" href="images/favicon.ico" />

    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}" />

    <link rel="stylesheet" href="{{asset('css/magnific-popup.css')}}" />

    <link rel="stylesheet" href="{{asset('css/circle.css')}}"/>

    <link rel="stylesheet" href="{{asset('css/chatbot.css')}}"/>

    <link rel="stylesheet" href="{{asset('css/typography.css')}}" />

    <link rel="stylesheet" href="{{asset('css/new.css')}}" />

    <link rel="stylesheet" href="{{asset('css/responsive.css')}}" />
    
    <link rel="stylesheet" href="{{asset('css/ourteam.css')}}" />