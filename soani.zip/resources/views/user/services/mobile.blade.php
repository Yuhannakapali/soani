@extends('frontend.layout.master')

@section('content')

@include('frontend.layout.breadcrums')

@include('frontend.section.mobile')
    
@endsection