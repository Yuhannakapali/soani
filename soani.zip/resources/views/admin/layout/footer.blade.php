<footer class="main-footer">
    <!-- To the right -->
    <div class="text-center">
      <strong>Copyright &copy; 2020 <a href="http://soanitech.com.">SoAniTech</a>.</strong> All rights reserved.
    </div>
    <!-- Default to the left -->
   
  </footer>