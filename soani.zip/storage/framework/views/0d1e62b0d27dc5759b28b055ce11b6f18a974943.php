<section class="iq-works mt-3">
        <div class="container">
          <div class="row justify-content-md-center">
            <div class="col-lg-8 col-sm-12 text-center">
              <div class="title-box">
                <h2 class="title text-dark">OUR <span>Services </span></h2>
                <p class="mt-2">Automate what you have.</p>
              </div>
            </div>
          </div>
          <div class="row align-items-center works-arrow1 m-top">
            <div class="col-lg-6 col-sm-12">
              <div class="title-box">
                <h1 class="title-light text-dark">
                  Various
                  <span>Services</span>
                </h1>
              </div>
              <p class="mt-4">
                We provide Reliable and Quality service.
              </p>
              <ul class="mt-4">
                <li class="mt-2">
                  <i class="fas fa-check-circle"></i> AR, ER and VR Solutions
                </li>
                <li class="mt-2">
                  <i class="fas fa-check-circle"></i> Mobile and Web application
                </li>
                <li class="mt-2">
                  <i class="fas fa-check-circle"></i> Website Design
                </li>
                <li class="mt-2">
                  <i class="fas fa-check-circle"></i> Digital Marketing
                </li>
              </ul>
            </div>
            <div class="col-lg-6 col-sm-12">
              <div class="works-box">
                <div
                  id="carouselExampleSlidesOnly"
                  class="carousel slide"
                  data-ride="carousel"
                >
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img
                        class="w-100 img-fluid top-bg"
                        src="images/works/work-bg.png"
                        alt="image"
                      />
                      <img
                        class="img-fluid works-img1"
                        src="images/works/work-bg.png"
                        alt="image"
                      />
                    </div>
                    <div class="carousel-item">
                      <img
                        class="w-100 img-fluid top-bg"
                        src="images/works/work-bg.png"
                        alt="image"
                      />
                      <img
                        class="img-fluid works-img1"
                        src="images/works/works-img1.png"
                        alt="image"
                      />
                    </div>
                    <div class="carousel-item">
                      <img
                        class="w-100 img-fluid top-bg"
                        src="images/works/work-bg.png"
                        alt="image"
                      />
                      <img
                        class="img-fluid works-img1"
                        src="images/works/works-img1.png"
                        alt="image"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
</section><?php /**PATH C:\Users\Kuro_neko\Documents\respo\soani\resources\views/frontend/section/services.blade.php ENDPATH**/ ?>