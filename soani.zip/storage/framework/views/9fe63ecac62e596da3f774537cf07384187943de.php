 


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">



        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Designation</th>
                <th scope="col"> Type of Member</th>
                <th scope="col"> Action</th>


              </tr>
            </thead>
            <tbody>
            
        <?php if(!empty($ourteams)): ?>
            <?php $__currentLoopData = $ourteams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ourteam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                  <tr>
                  <th scope="row"><?php echo e($ourteam->id); ?></th>
                    <td><?php echo e($ourteam->name); ?></td>
                    <td><?php echo e($ourteam->designation); ?></td>
                    <td><?php if($ourteam->board_of_director != 1): ?>
                            Execcutive team
                        <?php elseif($ourteam->executive_team != 1): ?>
                            Board of director                     
                        <?php else: ?>
                            B.of.d/E.team

                    <?php endif; ?></td>
                    <td> <a href="<?php echo e(route('ourteams.index')); ?>">Edit</a> | View </td>
                    </tr>               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/admin/addteam/index.blade.php ENDPATH**/ ?>