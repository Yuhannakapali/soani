 <!-- Control Sidebar -->
 <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/admin/layout/cotrolsidebar.blade.php ENDPATH**/ ?>