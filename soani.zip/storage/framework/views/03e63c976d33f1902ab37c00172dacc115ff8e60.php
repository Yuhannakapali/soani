<?php $member_available = isset($member) ? true :  false;?>
<?php echo e(csrf_field()); ?>

<div class="form-group">
    <div>
        <label for="name"> Name</label>
        <input
            type="text"
            class="form-control"
            placeholder="Eg. Jhon Doe"
            id="name"
            name="name"
            data-rule-maxlength="50"
            data-rule-minlength="3"
            required=""
            value="<?php echo e($member_available ?? '' ? $member->name : old('name')); ?>"
        />
    </div>
    <div>
        <label for="Designation"> Designation</label>
        <input
            type="text"
            class="form-control"
            placeholder="Eg. CTO"
            id="designation"
            name="designation"
            data-rule-maxlength="50"
            data-rule-minlength="3"
            required=""
            value="<?php echo e($member_available ?? '' ? $member->designation : old('designation')); ?>"
        />
    </div>
    <div>
        <label for="message"> Message</label>
        <textarea 
        class="form-control"
         id="message"
         name="message"
         rows="4"
         required=""
         >
         <?php echo e($member_available ?? '' ? $member->message : old('messsage')); ?>

        </textarea>
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    </div>
    
    <div>
        <label for="file">Choose a image file</label><br>
        <input type="file" name="file">

    </div>
    <span class="error-display">
        <i style="color: red;"> <?php echo $errors->first('image_name'); ?> </i>
    </span>
    
</div><?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/admin/forms/testimonial_form.blade.php ENDPATH**/ ?>