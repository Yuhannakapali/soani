<div id="banner" class="banner">
      <div class="banner-text">
        <div class="container">
          <div class="row">
            <div class="col-lg-5 col-md-12 col-sm-12">
              <div
                id="carouselExampleSlidesOnly"
                class="carousel slide"
                data-ride="carousel"
              >
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <h1 class="text-uppercase">OUR MISSION</h1>
                    <h3 class="mt-4">
                      Automate manual task
                      <br />

                      Making education fun

                      <br />

                      Providing mobile soultion
                    </h3>
                  </div>
                  <div class="carousel-item">
                    <h1 class="text-uppercase">OUR VISION</h1>
                    <h3 class="mt-4">
                      Automate manual task
                      <br />

                      Making education fun

                      <br />

                      Providing mobile soultion
                    </h3>
                  </div>
                  <div class="carousel-item">
                    <h1 class="text-uppercase">OUR MISSION</h1>
                    <h3 class="mt-4">
                      Automate manual task
                      <br />

                      Making education fun

                      <br />

                      Providing mobile soultion
                    </h3>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-7 col-md-12 col-sm-12 text-right">
              <img
                class="img-fluid banner-img"
                src="images/banner/banner-imgtest.png"
                alt="image"
              />
            </div>
          </div>
        </div>
      </div>
      <img
        class="img-fluid banner-after"
        src="images/banner/banner-after.png"
        alt="image"
      />
    </div><?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/frontend/section/slider.blade.php ENDPATH**/ ?>