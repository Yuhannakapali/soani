<link rel="shortcut icon" href="images/favicon.ico" />

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('css/circle.css')); ?>"/>

    <link rel="stylesheet" href="<?php echo e(asset('css/chatbot.css')); ?>"/>

    <link rel="stylesheet" href="<?php echo e(asset('css/typography.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('css/new.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>" />
    
    <link rel="stylesheet" href="<?php echo e(asset('css/ourteam.css')); ?>" /><?php /**PATH C:\Users\Kuro_neko\Documents\respo\soani\resources\views/frontend/layout/stylesheet.blade.php ENDPATH**/ ?>