<div class="breadcrumbs">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 col-sm-12">
                <h1 class="title">About Us</h1>
            </div>
            <div class="col-md-6 col-sm-12 text-right">
                <ul>
                    <li class="d-inline"><a href="index.html">Home</a></li>
                    <li class="d-inline active">About Us</li>
                </ul>
            </div>
        </div>
    </div>
    <img class="img-fluid breadcrumbs-after" src="images/banner/banner-after.png" alt="image">
</div><?php /**PATH C:\Users\Kuro_neko\Documents\respo\soani\resources\views/frontend/breadcrums.blade.php ENDPATH**/ ?>