<form class="form-validate" method="post" enctype="multipart/form-data"
                                action="<?php echo e(route('todos.store')); ?>">
                                <?php echo $__env->make('admin.forms.todo_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <div class="box-footer">
                                        <input class="btn btn-primary pull-right" type="submit" value="Create">
                                        <input class="btn btn-danger pull-left" type="reset" value="Reset">
                                    </div>
                                </div>
                            </form><?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/admin/todos/create.blade.php ENDPATH**/ ?>