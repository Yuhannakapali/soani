 


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-lg-3 col-sm-6">
            <div class="team-box mt-5">
                <div class="team-img position-relative">
                    <img class="img-fluid ot-image team-1" src="<?php echo e(asset('images/upload/'.$member->image_name)); ?>" alt="">
                    
                </div>
                <div class="mt-3 text-center">
                    <h5 class="title"><?php echo e($member->name); ?></h5>
                    <p><?php echo e($member->designation); ?></p>
                </div>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/admin/ourteam/show.blade.php ENDPATH**/ ?>