		

		<?php $__env->startSection('content'); ?>
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
					Todo Table
				</h1>
			</section>
		 <section class="content-header">
				<a href="<?php echo e(route('todos.create')); ?>" class="btn btn-primary pull-right"> <i class="fa fa-plus"></i>Create</a>
			

			</section>
		<!-- Main content -->
                
        
            <?php echo e($todo->name); ?>

            
		</div>
		
		
		<?php $__env->stopSection(); ?>
		
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/admin/todos/show.blade.php ENDPATH**/ ?>