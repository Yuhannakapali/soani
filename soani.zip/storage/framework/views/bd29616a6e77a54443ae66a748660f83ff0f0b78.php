<section class="iq-features">
  <div class="row align-items-center m-top">
    <div class="col-lg-6 col-sm-12">
      <div class="title-box">
        <h2 class="title-light text-dark">
          Our
          <span>Team</span>
        </h2>
      </div>
      <p class="mt-4">
        We are a team of Computer Engineers and Developers from
        different parts of Nepal, who are always eager to work on new
        technologies and present users with innovative products.SoAni
        Tech was established with the vision to digitalize what we have
        and to develop Software and e-Books for every person.
      </p>
      <a class="button grey mt-2" href="./about-us.html" role="button"
        >Read More</a
      >
    </div>
    <div class="col-lg-6 col-sm-12">
      <div class="works-box">
        <img
          class="img-fluid top-bg"
          src="images/works/work-bg.png"
          alt="image"
        />
        <img
          class="img-fluid works-img1"
          src="images/works/work-bg.png"
          alt="image"
        />
      </div>
    </div>
  </div>
  </div>
</section>  <?php /**PATH C:\Users\Kuro_neko\Documents\respo\soani\resources\views/frontend/section/ourteam.blade.php ENDPATH**/ ?>