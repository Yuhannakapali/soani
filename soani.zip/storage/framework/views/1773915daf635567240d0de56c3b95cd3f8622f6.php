		

		<?php $__env->startSection('content'); ?>
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1>
					Todo Table
				</h1>
			</section>
		 <section class="content-header">
				<a href="<?php echo e(route('todos.create')); ?>" class="btn btn-primary pull-right"> <i class="fa fa-plus"></i>Create</a>

			</section>
		<!-- Main content -->
							<table id="example1" class="table table-bordered table-striped">
								<thead>
									<tr>
										<th>Name</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr >
										<td><?php echo e($todo->name); ?></td>
										<td>
											<a class='btn btn-info btn-xs' style="margin-left:5px;"
											href="<?php echo e(route('todos.show', $todo)); ?>">
											<i class="fa fa-eye"></i>
											view
										</a>

										<a class='btn btn-info btn-xs' style="margin-left:5px;"
											href="<?php echo e(route('todos.edit', $todo)); ?>">
											<i class="fa fa-eye"></i>
											edit
										</a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		</table>
		</div>
		
		
		<?php $__env->stopSection(); ?>
		
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kuro_neko\Documents\respo\soani\resources\views/admin/todos/index.blade.php ENDPATH**/ ?>