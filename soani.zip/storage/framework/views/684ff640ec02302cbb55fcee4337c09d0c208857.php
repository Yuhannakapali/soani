

<?php $todo_available = isset($todo) ? true :  false;?>
<?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="name"> Name</label>
        <input type="text" class="form-control" placeholder="Eg.John Doe" id="name" name="name"
            data-rule-maxlength="50" data-rule-minlength="3" required=""
            value="<?php echo e($todo_available ? $todo->name : old('name')); ?>">
        <span class="error-display"><i style='color: red;'> <?php echo $errors->first('name'); ?> </i></span>
    </div>
	<?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/admin/forms/todo_form.blade.php ENDPATH**/ ?>