<!-- jQuery -->
<script src="<?php echo e(asset('./js/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('./js/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('./js/adminlte.min.js')); ?>"></script><?php /**PATH C:\Users\Kuro_neko\Documents\repo\soani\resources\views/admin/layout/js.blade.php ENDPATH**/ ?>